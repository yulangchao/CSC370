import java.sql.*;
import java.io.*;
import java.util.*;

class bag {
	public static void main (String args []) throws Exception{

		// build up an connection
		DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
		Connection conn = DriverManager.getConnection
		("jdbc:oracle:thin:@localhost:1522:studentdb", "c##dimei", "V00783547");

		//String filename = args[1];

		//input statements 
		Statement stmt = conn.createStatement();
		

		
		BufferedReader br = new BufferedReader(new FileReader("a.txt"));
 		String line = br.readLine();

		while (line != null) {

			String [] data = line.split("\\t+");	
			//System.out.println("INSERT INTO BAGGAGE VALUES('"+data[0] +"',"+ Integer.parseInt(data[1])+","+ "'" + data[2] + "')");
			stmt.executeUpdate("INSERT INTO BAGGAGE VALUES('"+data[0] +"',"+ Integer.parseInt(data[1])+","+ "'" + data[2] + "')");
        		line = br.readLine();
    		}

		stmt.close();
	}
}
